<?php

echo'
<div class="text-capitalize font-weight ">
<ul class=" text-center list-inline col-lg-12">
  <li class="align-text-top list-inline-item"><a class="text-white " href="Index.php">Home</a></li>
  <li class="text-white align-text-top list-inline-item">Historia da Arte
  <ul>
    <li><a href="Historia-da-arte.php" class="text-white ">Historia da Arte</a></li>
    <li><a href="#" class="float-left text-white ">Especies</a></li>
  </ul>
  </li>
  <li class="text-white align-text-top list-inline-item">Tatuagens
  <ul>
    <li><a href="#" class="text-white">Tipos de Tatuagens</a></li>
    <li><a href="#" class="float-left text-white ">Modelos</a></li>
  </ul>
  </li>
  <li class="text-white align-text-top list-inline-item">Arte e Cutura
  <ul>
    <li><a href="Arteecultura.php" class="text-white ">Arte e Cultura</a></li>
    <li><a href="#" class="float-left text-white ">Modelos</a></li>
  </ul>
  </li>
  <li class="text-white align-text-top list-inline-item">Arte Tribal
  <ul>
    <li><a href="Arte-tribal.php" class="text-white">tipos de  Arte Tribal</a></li>
    <li><a href="#" class="float-left text-white ">Modelos</a></li>
  </ul>
  </li>
  <li class="align-text-top list-inline-item"><a href="Quem-somos.php" class="text-white">Quem Somos</a></li>
  <li class="align-text-top list-inline-item"><a href="Contatos.php" class="text-white ">Contatos</a></li>
  <li class="align-text-top list-inline-item"><a href="termosdeuso.php" class="text-white"> Termos de Utilização. </a></li>
</ul> 
<small class=" text-white"> &copy; Dmitri Patrício de Lima, Carlos Daniel Barbosa Benfica, Vitor Gabriel Vicentini, Robert Richard Cruz da Silva </small>
</div>';