<?php

echo'<div class="col-lg-12">
<a href="Index.php"> 
<img src="images/Logo_HumArt_200x375.jpg" class="float-left" 
alt="Logo da empresa HumArt com duas pessoas de diferentes épocas escrevendo na parede." height="200" width="375"> 
</a>
</div>';